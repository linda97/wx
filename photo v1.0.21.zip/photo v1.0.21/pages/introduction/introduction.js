// pages/introduction/introduction.js
Page({
  data: {
    imgUrls: [
      'http://p0.so.qhimgs1.com/bdr/_240_/t01daf5625598ea3030.jpg',
      'http://p0.so.qhimgs1.com/bdr/_240_/t01496401524279448c.png',
      'http://p0.so.qhmsg.com/bdr/_240_/t01e3f14175c73d756f.jpg'
      ]
  },
  //事件处理函数
  toupper: function () {
    console.log("触发了toupper");
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})
